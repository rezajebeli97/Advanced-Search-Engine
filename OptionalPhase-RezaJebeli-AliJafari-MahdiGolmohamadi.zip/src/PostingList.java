import java.util.ArrayList;
import java.util.LinkedList;

public class PostingList {
	public PostingList(String word, ArrayList<Article> articles) {
		// TODO Auto-generated constructor stub
		this.word = word;
		this.articles = articles;
	}
	public String word;
	ArrayList<Article> articles;
}