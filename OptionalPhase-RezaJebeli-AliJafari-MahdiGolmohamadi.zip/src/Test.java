import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jhazm.tokenizer.WordTokenizer;

public class Test {
	public static void main(String[] args){
		
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(0);
		int x = 1;
		arr.add(1,x);
		System.out.println(arr.size());
		System.out.println(arr.get(1));
	}
}