
public class Sparse<T> {
	public int index;
	public T value;
	public Sparse(int index, T value) {
		this.index = index;
		this.value = value;
	}
}
