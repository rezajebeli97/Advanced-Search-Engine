import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.jsoup.Jsoup;

import jhazm.Lemmatizer;
import jhazm.Normalizer;
import jhazm.tokenizer.WordTokenizer;

public class RankedSearch implements DataStructure {
	public int numberOfRows;
	public int numberOfDocs;
	ArrayList<PostingList> dictionary = new ArrayList<PostingList>();
	HashMap<String, Integer> map = new HashMap<>();
	ArrayList<String> stopWords = new ArrayList<String>();
	ArrayList<String> correctHamsansaz = new ArrayList<String>();
	ArrayList<String> wrongHamsansaz = new ArrayList<String>();
	
	ArrayList<Sparse<Integer>>[] vectors;
	ArrayList<Sparse<Float>>[] tfidfVectors;
	int[] nt; // how many doc contains word t?
	private int numOfClusteringIterations = 10;
	private Cluster[] clusters;

	@Override
	public void build(File mainFile, File stopWordsFile, File hamsansazFile, File abbreviationFile,
			File tarkibiPorkarbordFile) {

		generateStopWords(stopWordsFile);

		generateHamsanSazWords(hamsansazFile);

		generateabbreviationWords(abbreviationFile);

		generateTarkibiPorkarbordWords(tarkibiPorkarbordFile);

		try {

			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(mainFile));
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			Static.sheet = wb.getSheetAt(0);
			HSSFRow row;
			HSSFCell cell;

			numberOfRows = Static.sheet.getPhysicalNumberOfRows(); // No of rows
			numberOfDocs = numberOfRows - 1;
			System.out.println("num of docs : " + numberOfDocs);

			int cols = 0; // No of columns
			int tmp = 0;

			// This trick ensures that we get the data properly even if it doesn't start
			// from first few rows
			for (int i = 0; i < 10 || i < numberOfRows; i++) {
				row = Static.sheet.getRow(i);
				if (row != null) {
					tmp = Static.sheet.getRow(i).getPhysicalNumberOfCells();
					if (tmp > cols)
						cols = tmp;
				}
			}

			Normalizer normalizer = new Normalizer();
			WordTokenizer tokenizer = new WordTokenizer();
			Lemmatizer lemmatizer = new Lemmatizer();

			for (int r = 1; r < numberOfRows; r++) {
				row = Static.sheet.getRow(r);
				if (row != null) {
					int c = 5; // choosing content column // for (int c = 0; c < cols; c++) {
					cell = row.getCell((short) c);

					if (cell != null) {
						int position = 0;
						String rawText = cell.getRichStringCellValue().getString();
						String noTag = Jsoup.parse(rawText).text();

						String noPunctuationTemp = noTag.replaceAll("\\p{Punct}", "");

						String noPunctuation = noPunctuationTemp.replaceAll("،", "");

						String normalized = normalizer.run(noPunctuation);

						// converting tarkibiPorkarbord words into it's common shape
						for (String s : Static.tarkibiPorkarbord) {
							normalized = normalized.replaceAll(s, s.replace(" ", ""));
						}
						// مخفف converting ج.ا to جمهوری اسلامی
						for (int i = 0; i < Static.wrongAbbreviation.size() ; i++) {
							String wrong = Static.wrongAbbreviation.get(i);
							String correct = Static.correctAbbreviation.get(i);
							normalized = normalized.replaceAll(wrong, correct);
						}

						List<String> tokens = tokenizer.tokenize(normalized);

						for (String s : tokens) {
							String word = lemmatizer.lemmatize(s);
							// stopword
							if (stopWords.contains(word)) {
								position++;
								continue;
							}
							// همسان ساز
							if (wrongHamsansaz.contains(word)) {
								word = correctHamsansaz.get(wrongHamsansaz.indexOf(word));
							}
							
							addWord(word, r, position);
							position++;
						}
					}
				}
			}

			System.out.println("num of unique words : " + map.size());

			vectors = new ArrayList[numberOfDocs];
			for (int i = 0; i < vectors.length; i++) {
				vectors[i] = new ArrayList<Sparse<Integer>>();
			}
			nt = new int[map.size()];

			for (int r = 1; r < numberOfRows; r++) {
				row = Static.sheet.getRow(r);
				if (row != null) {
					int c = 5; // choosing content column // for (int c = 0; c < cols; c++) {
					cell = row.getCell((short) c);

					if (cell != null) {
						String rawText = cell.getRichStringCellValue().getString();
						String noTag = Jsoup.parse(rawText).text();

						String noPunctuationTemp = noTag.replaceAll("\\p{Punct}", "");

						String noPunctuation = noPunctuationTemp.replaceAll("،", "");

						String normalized = normalizer.run(noPunctuation);

						// converting tarkibiPorkarbord words into it's common shape
						for (String s : Static.tarkibiPorkarbord) {
							normalized = normalized.replaceAll(s, s.replace(" ", ""));
						}
						
						// مخفف converting ج.ا to جمهوری اسلامی
						for (int i = 0; i < Static.wrongAbbreviation.size() ; i++) {
							String wrong = Static.wrongAbbreviation.get(i);
							String correct = Static.correctAbbreviation.get(i);
							normalized = normalized.replaceAll(wrong, correct);
						}

						List<String> tokens = tokenizer.tokenize(normalized);

						for (String s : tokens) {
							String word = lemmatizer.lemmatize(s);
							// stopword
							if (stopWords.contains(word))
								continue;
							// همسان ساز
							if (wrongHamsansaz.contains(word)) {
								word = correctHamsansaz.get(wrongHamsansaz.indexOf(word));
							}
							updateVector(r - 1, word);
						}
					}
				}
			}

			updateNt();
			
			// generating tfidf
			tfidfVectors = new ArrayList[numberOfDocs];
			for (int i = 0; i < tfidfVectors.length; i++) {
				tfidfVectors[i] = new ArrayList<Sparse<Float>>();
			}
			for (int i = 0; i < vectors.length; i++) {
				ArrayList<Sparse<Integer>> vector = vectors[i];
				for (Sparse<Integer> sparse : vector) {
					int index = sparse.index;
					int value = sparse.value;
					switch (Static.weightingScheme) {
					case 1:
						tfidfVectors[i].add(new Sparse<Float>(index, (float) (value * Math.log10((float)(numberOfDocs) / nt[index]))));
						break;
					case 2:
						tfidfVectors[i].add(new Sparse<Float>(index, (float) (1 + Math.log10(value))));
						break;
					case 3:
						tfidfVectors[i].add(new Sparse<Float>(index, (float) ((1 + Math.log10(value)) * Math.log10((float)(numberOfDocs) / nt[index]))));
						break;
					}
				}
			}

		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
		System.out.println("num of unique words : " + map.size());
		
		
		
		
		
		//TODO
		clustering(3);
		System.out.println("salam");
	}

	
	private void clustering(int k) {		//k = num of clusters
		clusters = new Cluster[k];
		for (int i = 0; i < k; i++) {
			clusters[i] = new Cluster();
			int centroidIndex = (int) (Math.random() * numberOfDocs);
			clusters[i].centroid = tfidfVectors[centroidIndex];
		}
		for (int iteration = 0; iteration < numOfClusteringIterations; iteration++) {
			for (int i = 0; i < clusters.length; i++) {
				clusters[i].indexes = new ArrayList<>();
			}
			for (int docIndex = 0; docIndex < tfidfVectors.length; docIndex++) {		// detect cluster for each data; به کدوم کلاستر نزدیکتره هر داک
				float max = 0;
				int maxClusterIndex = 0;
				for (int clusterIndex = 0; clusterIndex < clusters.length; clusterIndex++) {
					ArrayList<Sparse<Float>> centroid = clusters[clusterIndex].centroid;
					float similarity = similaritySparse(centroid, tfidfVectors[docIndex]);
					if (similarity > max) {
						max = similarity;
						maxClusterIndex = clusterIndex;
					}
				}
				clusters[maxClusterIndex].indexes.add(docIndex);
				
			}
			
			for (int clusterIndex = 0; clusterIndex < clusters.length; clusterIndex++) {	//compute centroid of each cluster
				ArrayList<Sparse<Float>> tmp = clusters[clusterIndex].centroid;
				for (int docIndex : clusters[clusterIndex].indexes) {
					tmp = addSparse(tfidfVectors[docIndex], tmp);
				}
				tmp = divisionSparse(tmp, clusters[clusterIndex].indexes.size());
				clusters[clusterIndex].centroid = tmp;
			}
		}
	}
	
	private ArrayList<Sparse<Float>> divisionSparse(ArrayList<Sparse<Float>> tmp, int size) {
		for (int i = 0; i < tmp.size(); i++) {
			tmp.get(i).value = tmp.get(i).value / 2;
		}
		return tmp;
	}


	private ArrayList<Sparse<Float>> addSparse(ArrayList<Sparse<Float>> sparseArray1, ArrayList<Sparse<Float>> sparseArray2) {
		float tmp = 0;
		int index1 = 0;
		int index2 = 0;
		ArrayList<Sparse<Float>> resultArray = new ArrayList<Sparse<Float>>();
		
		while (index1 < sparseArray1.size() && index2 < sparseArray2.size()) {
			int arr1Index = sparseArray1.get(index1).index;
			int arr2Index = sparseArray2.get(index2).index;
			float arr1Value = sparseArray1.get(index1).value;
			float arr2Value = sparseArray2.get(index2).value;
			
			if (arr1Index == arr2Index) {
				tmp += arr1Value + arr2Value;
				resultArray.add(new Sparse<Float>(arr1Index, tmp));
				index1++;
				index2++;
			}
			else if (arr1Index < arr2Index) {
				resultArray.add(new Sparse<Float>(arr1Index, arr1Value));
				index1++;
			}
			else {
				resultArray.add(new Sparse<Float>(arr2Index, arr2Value));
				index2++;
			}
		}
		
		if (index1 < sparseArray1.size()) {
			for (; index1 < sparseArray1.size(); index1++) {
				resultArray.add(new Sparse<Float>(sparseArray1.get(index1).index, sparseArray1.get(index1).value));
			}
		}
		if (index2 < sparseArray2.size()) {
			for (; index2 < sparseArray2.size(); index2++) {
				resultArray.add(new Sparse<Float>(sparseArray2.get(index2).index, sparseArray2.get(index2).value));
			}
		}
		return resultArray;
	}


	private float similaritySparse(ArrayList<Sparse<Float>> sparseArr1, ArrayList<Sparse<Float>> sparseArr2) {
		float tmp = 0;
		int index1 = 0;
		int index2 = 0;
		
		while (index1 < sparseArr1.size() && index2 < sparseArr2.size()) {
			int sparseArr1Index = sparseArr1.get(index1).index;
			int sparseArr2Index = sparseArr2.get(index2).index;
			
			if (sparseArr1Index == sparseArr2Index) {
				tmp += sparseArr1.get(index1).value * sparseArr2.get(index2).value;
				index1++;
				index2++;
			}
			else if (sparseArr1Index < sparseArr2Index) {
				index1++;
			}
			else {
				index2++;
			}
		}
		
		float sizeSparseArr1 = size(sparseArr1);
		float sizeSparseArr2 = size(sparseArr2);
		tmp /= ((float)sizeSparseArr1 * (float)sizeSparseArr2);
		
		return tmp;
	}


	private void zipfLaw() {
		MaxHeapInt maxHeap = new MaxHeapInt(nt);
		int[] res = maxHeap.heapSort(1000);

		for (int i : res) {
			System.out.println(i);
		}
	}

	private void updateNt() {
		for (ArrayList<Sparse<Integer>> arrayList : vectors)
			for (Sparse sparse : arrayList)
				nt[sparse.index] += 1;
	}

	@Override
	public PostingList search(String myString) {

		Normalizer normal = new Normalizer(true, false, true);
		myString = normal.run(myString);

		// converting بنا بر این to بنابراین
		for (String s : Static.tarkibiPorkarbord) {
			myString = myString.replaceAll(s, s.replace(" ", ""));
		}
		
		// مخفف converting ج.ا to جمهوری اسلامی
		for (int i = 0; i < Static.wrongAbbreviation.size() ; i++) {
			String wrong = Static.wrongAbbreviation.get(i);
			String correct = Static.correctAbbreviation.get(i);
			myString = myString.replaceAll(wrong, correct);
		}

		PostingList postingList = search3(myString);

		if (postingList == null)
			return null;
		return rankArticles(myString, postingList.articles);

	}

	public PostingList search3(String myString) {
		PostingList result;
		if (quoteFul(myString)) {
			String subString = removeQuote(myString);
			String[] strs = tokenize(subString);
			PostingList[] pls = new PostingList[strs.length];
			for (int i = 0; i < strs.length; i++) {
				pls[i] = search3(strs[i]);
			}
			result = neighbourhood(pls);
		} else if (notFul(myString)) {
			String subString = removeNot(myString);
			PostingList pl = search3(subString);
			result = not(pl);
		} else if (singleWord(myString)) {
			Lemmatizer lemmatize = null;
			try {
				lemmatize = new Lemmatizer();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			myString = lemmatize.lemmatize(myString);
			if (wrongHamsansaz.contains(myString)) {
				myString = correctHamsansaz.get(wrongHamsansaz.indexOf(myString));
			}
			result = getDictionary(myString);
		} else { // and
			String[] strs = tokenize(myString);
			PostingList[] pls = new PostingList[strs.length];
			for (int i = 0; i < strs.length; i++) {
				pls[i] = search3(strs[i]);
			}
			result = interSection(pls);
		}
		return result;

	}

	public PostingList rankArticles(String myString, ArrayList<Article> articles) {

		Normalizer normal = new Normalizer();

		// converting بنا بر این to بنابراین
		for (String s : Static.tarkibiPorkarbord) {
			myString = myString.replaceAll(s, s.replace(" ", ""));
		}
		// مخفف converting ج.ا to جمهوری اسلامی
		for (int i = 0; i < Static.wrongAbbreviation.size() ; i++) {
			String wrong = Static.wrongAbbreviation.get(i);
			String correct = Static.correctAbbreviation.get(i);
			myString = myString.replaceAll(wrong, correct);
		}

		String[] strs = tokenizeRanked(myString);

		// Lemmatize
		try {
			Lemmatizer lemmatize = new Lemmatizer();
			for (int i = 0; i < strs.length; i++) {
				strs[i] = lemmatize.lemmatize(strs[i]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (int i = 0; i < strs.length; i++) {
			if (wrongHamsansaz.contains(strs[i])) {
				strs[i] = correctHamsansaz.get(wrongHamsansaz.indexOf(strs[i]));
			}
		}

		ArrayList<Sparse<Integer>> queryVector = new ArrayList<Sparse<Integer>>();
		
		for (String string : strs) {
			if (map.get(string) == null)
				continue;
			
			int wordIndex = map.get(string);
			
			for (int i=0; i <= queryVector.size(); i++) {
				if (i == queryVector.size()) {
					Sparse sparse = new Sparse<Integer>(wordIndex, 1);
					queryVector.add(i, sparse);
					break;
				}
				else if (queryVector.get(i).index == wordIndex) {
					queryVector.get(i).value ++;
					break;
				}
				else if (queryVector.get(i).index > wordIndex) {
					Sparse sparse = new Sparse<Integer>(wordIndex, 1);
					queryVector.add(i, sparse);
					break;
				}
			}
			
		}
		
		ArrayList<Sparse<Float>> queryTfidfVector = new ArrayList<Sparse<Float>>();
		
		float max = 0;
		for (Sparse<Integer> sparse : queryVector) {
			max = Math.max(max, sparse.value);
		}
		for (Sparse<Integer> sparse : queryVector) {
			int index = sparse.index;
			int value = sparse.value;
			switch (Static.weightingScheme) {
			case 1:
				queryTfidfVector.add(new Sparse<Float>(index, (float) ((0.5 + (float)sparse.value / (2 * max)) * Math.log10((float)(numberOfDocs) / nt[index]))));
				break;
			case 2:
				
				queryTfidfVector.add(new Sparse<Float>(index, (float) Math.log10(1 + (float)(numberOfDocs) / nt[index])));
				break;
			case 3:
				queryTfidfVector.add(new Sparse<Float>(index, (float) ((1 + Math.log10(sparse.value)) * Math.log10((float)(numberOfDocs) / nt[index]))));
				break;
			}
		}

		float[] similarity = new float[articles.size()];
		for (int i = 0; i < articles.size(); i++) {
			// check articles[i].articleNumber - 1
			ArrayList<Sparse<Float>> tfidfVector = tfidfVectors[articles.get(i).articleNumber - 1];
			float tmp = similaritySparse(tfidfVector, queryTfidfVector);
//			float sizeTfidfVector = size(tfidfVector);
//			float sizeQueryTfidfVector = size(queryTfidfVector);
//			tmp /= ((float)sizeTfidfVector * (float)sizeQueryTfidfVector);
			similarity[i] = tmp;
		}

		MaxHeap maxHeap = new MaxHeap(similarity);
		int[] sortedArticlesIndexes = maxHeap.heapSort(Static.selectedNumber); // this returns article indexes from 0 to
																		// similarity.length - 1

		ArrayList<Article> sortedArticles = new ArrayList<>();

		for (int i : sortedArticlesIndexes) {
			sortedArticles.add(articles.get(i));
		}

		return new PostingList("", sortedArticles);
	}
	
	private float size(ArrayList<Sparse<Float>> arrayList) {
		float result = 0;
		for (Sparse<Float> sparse : arrayList) {
			result += Math.pow(sparse.value, 2);
		}
		if (result == 0)
			return (float) 0.001;
		result = (float) Math.sqrt(result);
		return result;
	}

	private void updateVector(int articleIndex, String word) {
		int wordIndex = map.get(word);
		ArrayList<Sparse<Integer>> vector = vectors[articleIndex];
		for (int i = 0; i <= vector.size(); i++) {
			if (i == vector.size()) {
				Sparse sparse = new Sparse<Integer>(wordIndex, 1);
				vector.add(i, sparse);
				break;
			}
			if (vector.get(i).index == wordIndex) {
				vector.get(i).value ++;
				break;
			}
			else if (vector.get(i).index > wordIndex) {
				Sparse sparse = new Sparse<Integer>(wordIndex, 1);
				vector.add(i, sparse);
				break;
			}
		}
	}

	private void addWord(String word, int articleNumber, int position) {
		if (map.get(word) == null) {
			map.put(word, map.size());
		}
		PostingList postingList = getDictionary(word);
		if (postingList == null) {
			ArrayList<Integer> positions = new ArrayList<Integer>();
			positions.add(position);
			ArrayList<Article> articles = new ArrayList<Article>();
			Article article = new Article(articleNumber, positions);
			articles.add(article);
			PostingList newPstList = new PostingList(word, articles);
			dictionary.add(newPstList);
		} else {
			Article article = getArticle(postingList, articleNumber);
			if (article == null) {
				ArrayList<Integer> positions = new ArrayList<Integer>();
				positions.add(position);
				Article newArticle = new Article(articleNumber, positions);
				postingList.articles.add(newArticle);
			} else if (!articleContains(article, position))
				article.positions.add(position);
		}
	}

	private void generateStopWords(File stopWordsFile) {
		// generating stopwords array
		try {
			Scanner scr = new Scanner(stopWordsFile);
			while (scr.hasNextLine()) {
				String stopWord = scr.nextLine();
				stopWords.add(stopWord);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void generateHamsanSazWords(File hamsansazFile) {
		// generating همسان ساز array. I supposed hamsansaz is for 2 words
		try {
			Scanner scr = new Scanner(hamsansazFile);
			while (scr.hasNextLine()) {
				String hamsan = scr.nextLine();
				String[] hamsans = hamsan.split(" ");
				correctHamsansaz.add(hamsans[0]);
				wrongHamsansaz.add(hamsans[1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void generateabbreviationWords(File abbreviationFile) {
		Static.wrongAbbreviation = new ArrayList<String>();
		Static.correctAbbreviation = new ArrayList<String>();
		try {
			Scanner scr = new Scanner(abbreviationFile);
			while (scr.hasNextLine()) {
				String hamsan = scr.nextLine();
				int tmp = hamsan.indexOf(" ");
				String wrong = hamsan.substring(0, tmp);
				String correct = hamsan.substring(tmp + 1);
				Static.correctAbbreviation.add(correct);
				Static.wrongAbbreviation.add(wrong);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void generate(File hamsansazFile) {
		// generating همسان ساز array. I supposed hamsansaz is for 2 words
		try {
			Scanner scr = new Scanner(hamsansazFile);
			while (scr.hasNextLine()) {
				String hamsan = scr.nextLine();
				String[] hamsans = hamsan.split(" ");
				correctHamsansaz.add(hamsans[0]);
				wrongHamsansaz.add(hamsans[1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void generateTarkibiPorkarbordWords(File tarkibiPorkarbordFile) {
		// generating tarkibiPorkarbord array
		Static.tarkibiPorkarbord = new ArrayList<String>();
		try {
			Scanner scr = new Scanner(tarkibiPorkarbordFile);
			while (scr.hasNextLine()) {
				String tarkibi = scr.nextLine();
				Static.tarkibiPorkarbord.add(tarkibi);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private PostingList getDictionary(String word) {
		for (PostingList postingList : dictionary)
			if (postingList.word.equals(word))
				return postingList;
		return null;
	}

	private Article getArticle(PostingList postingList, int articleIndex) {
		for (Article article : postingList.articles)
			if (article.articleNumber == articleIndex)
				return article;
		return null;
	}

	private boolean articleContains(Article article, int positionIndex) {
		for (Integer position : article.positions)
			if (position == positionIndex)
				return true;
		return false;
	}

	private String removeNot(String myString) {
		return myString.substring(1, myString.length());
	}

	private String removeQuote(String myString) {
		return myString.substring(1, myString.length() - 1);
	}

	private boolean quoteFul(String myString) {
		if (('"' == myString.charAt(myString.length() - 1)) && ('"' == myString.charAt(0))
				&& !removeQuote(myString).contains("\""))
			return true;
		return false;
	}

	private boolean notFul(String myString) {
		if ('!' == myString.charAt(0)) {
			String myString2 = myString.substring(1, myString.length());
			if (quoteFul(myString2)) {
				return true;
			}
			if (singleWord(myString2)) {
				return true;
			}
			return false;
		}
		return false;
	}

	private boolean singleWord(String myString) {
		if (myString.contains(" ")) {
			return false;
		}
		return true;
	}

	public String[] tokenize(String myString) {
		ArrayList<String> tokens = new ArrayList<>();
		for (int i = 0; i < myString.length();) {
			char c = myString.charAt(i);
			if (c == '"') {
				int j = i + 1;
				while (j < myString.length() && myString.charAt(j) != '"') {
					j++;
				}
				tokens.add(myString.substring(i, j + 1));
				i = j + 1;
			} else if (c == '!') {
				int j = i + 1;
				if (myString.charAt(j) == '"') {
					int k = j + 1;
					while (k < myString.length() && myString.charAt(k) != '"') {
						k++;
					}
					tokens.add(myString.substring(i, k + 1));
					i = k + 1;
				} else {
					int k = j + 1;
					while (k < myString.length() && myString.charAt(k) != ' ') {
						k++;
					}
					tokens.add(myString.substring(i, k));
					i = k + 1;
				}
			} else if (c == ' ') {
				i++;
			} else {
				int j = i + 1;
				while (j < myString.length() && myString.charAt(j) != ' ') {
					j++;
				}
				tokens.add(myString.substring(i, j));
				i = j + 1;
			}
		}
		String[] tokens_arr = new String[tokens.size()];
		for (int i = 0; i < tokens_arr.length; i++) {
			tokens_arr[i] = tokens.get(i);
		}
		return tokens_arr;
	}

	public String[] tokenizeRanked(String myString) {
		ArrayList<String> tokens = new ArrayList<>();
		for (int i = 0; i < myString.length();) {
			char c = myString.charAt(i);
			if (c == '"') {
				int j = i + 1;
				while (j < myString.length() && myString.charAt(j) != '"') {
					if (myString.charAt(j) == ' ') {
						tokens.add(myString.substring(i + 1, j));
						i = j;
					}
					j++;
				}
				tokens.add(myString.substring(i + 1, j));
				i = j + 1;
			} else if (c == '!') {
				int j = i + 1;
				if (myString.charAt(j) == '"') {
					int k = j + 1;
					while (k < myString.length() && myString.charAt(k) != '"') {
						k++;
					}
					i = k + 1;
				} else {
					int k = j + 1;
					while (k < myString.length() && myString.charAt(k) != ' ') {
						k++;
					}
					i = k + 1;
				}
			} else if (c == ' ') {
				i++;
			} else {
				int j = i + 1;
				while (j < myString.length() && myString.charAt(j) != ' ') {
					j++;
				}
				tokens.add(myString.substring(i, j));
				i = j + 1;
			}
		}

		String[] tokens_arr = new String[tokens.size()];
		for (int i = 0; i < tokens_arr.length; i++) {
			tokens_arr[i] = tokens.get(i);
		}
		return tokens_arr;
	}

	private PostingList interSection(PostingList[] pls) {
		PostingList result = interSection(pls[0], pls[1]);
		for (int i = 2; i < pls.length; i++) {
			result = interSection(result, pls[i]);
		}
		return result;
	}

	@Override
	public PostingList interSection(PostingList postingList1, PostingList postingList2) {
		// PostingList postingList1 = getDictionary(word1);
		// PostingList postingList2 = getDictionary(word2);
		PostingList newPostingList = new PostingList("", new ArrayList<Article>());
		if (postingList1 == null || postingList2 == null)
			return null;

		int x = 0;
		int y = 0;
		while (x < postingList1.articles.size() && y < postingList2.articles.size()) {
			Article article1 = postingList1.articles.get(x);
			Article article2 = postingList2.articles.get(y);
			if (article1.articleNumber == article2.articleNumber) {
				ArrayList<Integer> newPositions = new ArrayList<Integer>();
				for (Integer integer : article1.positions)
					newPositions.add(integer);
				for (Integer integer : article2.positions)
					newPositions.add(integer);

				Article article = new Article(article1.articleNumber, newPositions);
				newPostingList.articles.add(article);
				x++;
				y++;
			} else if (article1.articleNumber < article2.articleNumber)
				x++;
			else
				y++;

		}
		return newPostingList;
	}

	@Override
	public PostingList neighbourhood(PostingList[] pls) {
		// PostingList[] pls = new PostingList[words.length];
		// for (int i = 0; i < pls.length; i++) {
		// pls[i] = getDictionary(words[i]);
		// }
		PostingList result = new PostingList("", new ArrayList<Article>());
		for (int i = 0; i < pls[0].articles.size(); i++) {
			for (int j = 0; j < pls[0].articles.get(i).positions.size(); j++) {
				boolean t = true;
				for (int k = 1; k < pls.length; k++) {
					Article artc = getArticle(pls[k], pls[0].articles.get(i).articleNumber);
					if (artc != null) {
						if (articleContains(artc, pls[0].articles.get(i).positions.get(j) + k)) {
							if (k == pls.length - 1) {
								if (result.articles.size() == 0 || result.articles.get(result.articles.size()
										- 1).articleNumber != pls[0].articles.get(i).articleNumber)
									result.articles.add(new Article(pls[0].articles.get(i).articleNumber,
											new ArrayList<Integer>()));
								result.articles.get(result.articles.size() - 1).positions
										.add(pls[0].articles.get(i).positions.get(j));
							}
						} else
							break;
					} else {
						t = false;
						break;
					}
				}
				if (!t)
					break;
			}
		}
		return result;
	}

	@Override
	public PostingList not(PostingList postingList) {
		// PostingList postingList = getDictionary(word);
		PostingList newPostingList = new PostingList("", new ArrayList<Article>());
		for (int j = 1; j < postingList.articles.get(0).articleNumber; j++) { // from 1st article till [0] article
			Article article = new Article(j, new ArrayList<Integer>());
			newPostingList.articles.add(article);
		}
		for (int i = 1; i < postingList.articles.size(); i++) {
			for (int j = postingList.articles.get(i - 1).articleNumber + 1; j < postingList.articles
					.get(i).articleNumber; j++) {
				Article article = new Article(j, new ArrayList<Integer>());
				newPostingList.articles.add(article);
			}
		}
		for (int j = postingList.articles.get(postingList.articles.size() - 1).articleNumber
				+ 1; j <= numberOfRows; j++) { // from [last] article ill the last article
			Article article = new Article(j, new ArrayList<Integer>());
			newPostingList.articles.add(article);
		}
		return newPostingList;
	}

}
