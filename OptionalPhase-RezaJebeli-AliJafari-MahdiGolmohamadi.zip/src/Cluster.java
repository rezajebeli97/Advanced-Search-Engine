import java.util.ArrayList;

public class Cluster {
	public ArrayList<Integer> indexes;
	public ArrayList<Sparse<Float>> centroid;
	
	public Cluster() {
		indexes = new ArrayList<Integer>();
	}
}