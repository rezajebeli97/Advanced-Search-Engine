import java.util.ArrayList;

public class Article {
	public Article(int articleNumber, ArrayList<Integer> positions) {
		this.articleNumber = articleNumber;
		this.positions = positions;
	}
	public int articleNumber;
	public ArrayList<Integer> positions;
}
