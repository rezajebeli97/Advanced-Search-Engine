import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jhazm.*;
import jhazm.tokenizer.WordTokenizer;

public class Test {
	public static void main(String[] args) {
		Test t = new Test();
		String myString = "اصلاح نويسه ها و !استفاده از کتاب های \"دانشگاه تهران\" نیم‌فاصله پردازش را آسان مي كند";
		Normalizer normalizer = new Normalizer(true, false, true);

		myString = normalizer.run(myString);
		System.out.println(myString);

	}

	public String[] tokenize2(String myString) {
		ArrayList<String> tokens = new ArrayList<>();
		for (int i = 0; i < myString.length();) {
			char c = myString.charAt(i);
			if (c == '"') {
				int j = i + 1;
				while (myString.charAt(j) != '"') {
					j++;
				}
				tokens.add(myString.substring(i, j + 1));
				i = j + 1;
			} else if (c == '!') {

			} else {

			}
		}
	}

	public String[] tokenize(String myString) {
		char c = myString.charAt(0);
		if (c == '"') {
			int j = 1;
			while (myString.charAt(j) != '"') {
				j++;
			}
			String subString = myString.substring(0, j + 1);
			myString = myString.substring(j + 1, myString.length());
		} else if (c == '!') {
			String[] otherTokens = tokenize(myString.substring(1, myString.length()));
			otherTokens[0] = "/!".concat(otherTokens[0]);
		} else {

		}
		
		String[] otherTokens = tokenize(myString);
		String[] tokens = new String[otherTokens.length + 1];
		tokens[0] = subString;
		
		for (int i = 0; i < otherTokens.length; i++) {
			tokens[i+1] = otherTokens[i];
		}
		return tokens;
	}

}
