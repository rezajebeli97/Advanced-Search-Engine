public class SearchResult {
	String context;
}