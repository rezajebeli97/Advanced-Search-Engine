import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.jsoup.Jsoup;

import jhazm.Lemmatizer;
import jhazm.Normalizer;
import jhazm.tokenizer.WordTokenizer;

public class RankedSearch implements DataStructure{
	public int numberOfRows;
	public int numberOfDocs;
	HashMap<String, Integer> map = new HashMap<>();
	ArrayList<String> stopWords = new ArrayList<String>();
	ArrayList<String> correctHamsansaz = new ArrayList<String>();
	ArrayList<String> wrongHamsansaz = new ArrayList<String>();
	int[][] vectors;
	float[][] tfidfVectors;
	int[] nt; // how many doc has word t?
	int selectedNumber = 80;

	@Override
	public void build(File mainFile, File stopWordsFile, File hamsansazFile, File tarkibiPorkarbordFile) {

		generateStopWords(stopWordsFile);

		generateHamsanSazWords(hamsansazFile);

		generateTarkibiPorkarbordWords(tarkibiPorkarbordFile);

		try {

			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(mainFile));
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			Static.sheet = wb.getSheetAt(0);
			HSSFRow row;
			HSSFCell cell;

			numberOfRows = Static.sheet.getPhysicalNumberOfRows(); // No of rows
			numberOfDocs = numberOfRows - 1;
			System.out.println(numberOfDocs);

			int cols = 0; // No of columns
			int tmp = 0;

			// This trick ensures that we get the data properly even if it doesn't start
			// from first few rows
			for (int i = 0; i < 10 || i < numberOfRows; i++) {
				row = Static.sheet.getRow(i);
				if (row != null) {
					tmp = Static.sheet.getRow(i).getPhysicalNumberOfCells();
					if (tmp > cols)
						cols = tmp;
				}
			}

			Normalizer normalizer = new Normalizer();
			WordTokenizer tokenizer = new WordTokenizer();
			Lemmatizer lemmatizer = new Lemmatizer();

			for (int r = 1; r < numberOfRows; r++) {
				row = Static.sheet.getRow(r);
				if (row != null) {
					int c = 5; // choosing content column // for (int c = 0; c < cols; c++) {
					cell = row.getCell((short) c);

					if (cell != null) {
						String rawText = cell.getRichStringCellValue().getString();
						String noTag = Jsoup.parse(rawText).text();

						String noPunctuationTemp = noTag.replaceAll("\\p{Punct}", "");

						String noPunctuation = noPunctuationTemp.replaceAll("،", "");

						String normalized = normalizer.run(noPunctuation);

						// converting tarkibiPorkarbord words into it's common shape
						for (String s : Static.tarkibiPorkarbord) {
							noPunctuation = noPunctuation.replaceAll(s, s.replace(" ", ""));
						}

						List<String> tokens = tokenizer.tokenize(normalized);

						for (String s : tokens) {
							String word = lemmatizer.lemmatize(s);
							// stopword
							if (stopWords.contains(word))
								continue;
							// همسان ساز
							if (wrongHamsansaz.contains(word)) {
								word = correctHamsansaz.get(wrongHamsansaz.indexOf(word));
							}
							addWord(word);
						}
					}
				}
			}
			
			System.out.println(map.size());
			
			vectors = new int[numberOfDocs][map.size()];
			nt = new int[map.size()];
			
			for (int r = 1; r < numberOfRows; r++) {
				row = Static.sheet.getRow(r);
				if (row != null) {
					int c = 5; // choosing content column // for (int c = 0; c < cols; c++) {
					cell = row.getCell((short) c);
					
					if (cell != null) {
						String rawText = cell.getRichStringCellValue().getString();
						String noTag = Jsoup.parse(rawText).text();
						
						String noPunctuationTemp = noTag.replaceAll("\\p{Punct}", "");
						
						String noPunctuation = noPunctuationTemp.replaceAll("،", "");
						
						String normalized = normalizer.run(noPunctuation);
						
						// converting tarkibiPorkarbord words into it's common shape
						for (String s : Static.tarkibiPorkarbord) {
							noPunctuation = noPunctuation.replaceAll(s, s.replace(" ", ""));
						}
						
						List<String> tokens = tokenizer.tokenize(normalized);
						
						for (String s : tokens) {
							String word = lemmatizer.lemmatize(s);
							// stopword
							if (stopWords.contains(word))
								continue;
							// همسان ساز
							if (wrongHamsansaz.contains(word)) {
								word = correctHamsansaz.get(wrongHamsansaz.indexOf(word));
							}
							updateVector(r-1, word);
						}
						updateNt(r-1);
					}
				}
			}
			
			//generating tfidf
			tfidfVectors = new float[numberOfDocs][map.size()];
			for (int i = 0; i < vectors.length; i++) {
				for (int j = 0; j < vectors[0].length; j++) {
					if (vectors[i][j] == 0)
						continue;
					tfidfVectors[i][j] = (float) ((1 + Math.log10(vectors[i][j])) * Math.log10((numberOfDocs) / nt[j]));
				}
			}
			
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
		System.out.println(map.size());
		
	}

	private void updateNt(int articleIndex) {
		for (int i = 0; i < nt.length; i++) {
			if (vectors[articleIndex][i] != 0) {
				nt[i] += 1;
			}
		}
	}

	@Override
	public PostingList search(String myString) {
		System.out.println(myString);
	
		Normalizer normal = new Normalizer();
	
		// converting بنا بر این to بنابراین
		for (String s : Static.tarkibiPorkarbord) {
			myString = myString.replaceAll(s, s.replace(" ", ""));
		}
	
		String[] strs_basic = myString.split(" ");
		int z = 0;
		for (int i = 0; i < strs_basic.length; i++) {
			if (!strs_basic[i].equals("") && !stopWords.contains(strs_basic[i])) {
				strs_basic[z] = strs_basic[i];
				z++;
			}
		}
	
		String[] strs = new String[z];
		for (int i = 0; i < z; i++) {
			// همسان ساز
			if (wrongHamsansaz.contains(strs_basic[i]))
				strs[i] = correctHamsansaz.get(wrongHamsansaz.indexOf(strs_basic[i]));
	
			else
				strs[i] = strs_basic[i];
	
		}
	
		try {
			Lemmatizer lemmatize = new Lemmatizer();
			for (int i = 0; i < strs.length; i++) {
				strs[i] = lemmatize.lemmatize(strs[i]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		int[] queryVector = new int[map.size()];
		for (String string : strs) {
			if (map.get(string) != null) {
				queryVector[map.get(string)] ++;
			}
		}
		
		float[] queryTfidfVector = new float[map.size()];
		for (int j = 0; j < map.size(); j++) {
			if (queryVector[j] == 0)
				continue;
			queryTfidfVector[j] = (float) ((1 + Math.log10(queryVector[j])) * Math.log10((numberOfDocs) / nt[j]));
		}
		
		float[] similarity = new float[numberOfDocs];
		for (int i = 0; i < tfidfVectors.length; i++) {
			float[] tfidfVector = tfidfVectors[i];
			float tmp = 0;
			for (int j = 0; j < tfidfVector.length; j++) {
				tmp += tfidfVector[j] * queryTfidfVector[j];
			}
			float sizeTfidfVector = size(tfidfVector);
			float sizeQueryTfidfVector = size(queryTfidfVector);
			tmp /= (sizeTfidfVector * sizeQueryTfidfVector);
			similarity[i] = tmp;
		}
		
		MaxHeap maxHeap = new MaxHeap(similarity);
		int[] sortedArticles = maxHeap.heapSort(selectedNumber);		//this returns article indexes from 0 to 1729
		
		for (int i : sortedArticles) {
			System.out.println(i+1);		//i+1  is article number
		}
		
		return null;
	}

	private float size(float[] arr) {
		float result = 0;
		for (int i = 0; i < arr.length; i++) {
			result += Math.pow(arr[i], 2);
		}
		if (result == 0)
			return (float) 0.001;
		result = (float) Math.sqrt(result);
		return result;
	}

	private void updateVector(int articleIndex, String word) {
		int wordIndex = map.get(word);
		vectors[articleIndex][wordIndex] ++;
	}

	private void addWord(String word) {
		if (map.get(word) == null) {
			map.put(word, map.size());
		}
	}

	private void generateStopWords(File stopWordsFile) {
		// generating stopwords array
		try {
			Scanner scr = new Scanner(stopWordsFile);
			while (scr.hasNextLine()) {
				String stopWord = scr.nextLine();
				stopWords.add(stopWord);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void generateHamsanSazWords(File hamsansazFile) {
		// generating همسان ساز array. I supposed hamsansaz is for 2 words
		try {
			Scanner scr = new Scanner(hamsansazFile);
			while (scr.hasNextLine()) {
				String hamsan = scr.nextLine();
				String[] hamsans = hamsan.split(" ");
				correctHamsansaz.add(hamsans[0]);
				wrongHamsansaz.add(hamsans[1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void generateTarkibiPorkarbordWords(File tarkibiPorkarbordFile) {
		// generating tarkibiPorkarbord array
		Static.tarkibiPorkarbord = new ArrayList<String>();
		try {
			Scanner scr = new Scanner(tarkibiPorkarbordFile);
			while (scr.hasNextLine()) {
				String tarkibi = scr.nextLine();
				Static.tarkibiPorkarbord.add(tarkibi);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public PostingList interSection(PostingList postingList1, PostingList postingList2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostingList neighbourhood(PostingList[] pls) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostingList not(PostingList postingList) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
